<?php 
	require_once "../api/Common/config.php";
	require_once "../api/Common/functions.php";
	token_refresh();
?> 