<meta name="description" content="Автоматизація всіх процесів медустанов. Інтегрований додаток eНealth для OpenEMR.">
