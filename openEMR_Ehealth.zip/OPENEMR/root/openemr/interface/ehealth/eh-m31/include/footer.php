<!-- ==================== FOOTER ================== -->
<div class="main-footer clearfix">
    <div class="footer-pane">
        <div class="container clearfix">
            <div class="logo">&copy; 2021 SCSMED. Всі права захищенні. <br>eHealth for OpenEMR.</div>
        </div>
    </div>
</div>

<div class="scroll-btn">
     <div class="scroll-btn-arrow"></div>
</div>
<!-- ============================================ -->

