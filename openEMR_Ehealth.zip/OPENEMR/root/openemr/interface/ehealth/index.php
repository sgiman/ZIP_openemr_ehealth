<?php
//--- REDIRECT to LOGIN ---
$location = "Location: https://sgiman.com.ua/openemr/interface/ehealth/eh-m31/Login.php";
header($location, TRUE, 301);
exit();
?>
